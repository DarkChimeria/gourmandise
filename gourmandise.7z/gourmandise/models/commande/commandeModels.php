<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

// include 'models.php';

function listeCommandes(){
	$cnx = getBD();
	$sql = 'SELECT * FROM commande';
	$idResult  = executeR($cnx,$sql);
	return $idResult;
}

function detailsCommande($id){
	$cnx = getBD();
	$sql = 'SELECT * FROM commande WHERE numero = ?';
	$idResult  = executeR($cnx,$sql, array($id));
	return $idResult;
}

function commandeLignes($id){
	$cnx = getBD();
	$sql = 'SELECT * FROM ligne_commande WHERE numero = ?';
	$idResult2  = executeR($cnx,$sql, array($id));
	return $idResult2;
}

// 	function commandeClient($codec){
// 	$cnx = getBD();
// 	$sql2 = 'SELECT * FROM client WHERE code_c = ?';
// 	$idResult3  = executeR($cnx,$sql2, array($id));
// 	return $idResult3;
// }


function ajoutCommande($codev,$codec,$dateliv,$datecommande,$totalht,$totaltva,$etat){
	$cnx = getBD();
	$sql = 'INSERT INTO commande (code_v,code_c,date_livraison,date_commande,total_ht,total_tva,etat) VALUES (?,?,?,?,?,?,?)';
	$idResult  = executeR($cnx,$sql, array($codev,$codec,$dateliv,$datecommande,$totalht,$totaltva,$etat));
	Header( 'Location: index.php?gestion=commande&success=1' );
}

// function suppressionProduit($id){
// 	$cnx = getBD();
// 	$sql = 'DELETE FROM Produit WHERE reference = ?';
// 	$idResult  = executeR($cnx,$sql, array($id));
// 	Header( 'Location: index.php?success=3' );
// }

// function editionProduit($id,$designation){
// 	$cnx = getBD();
// 	$sql = 'UPDATE Produit SET designation=? WHERE reference = ?';
// 	$idResult  = executeR($cnx,$sql, array($designation,$id));
// 	Header( 'Location: index.php?success=2' );
// }