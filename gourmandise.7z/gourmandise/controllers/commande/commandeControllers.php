<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once '/models/produit/produitModels.php';
require_once '/models/commande/commandeModels.php';

function liste(){
	$idResult = listeCommandes();
	require_once '/views/commande/commandeViewsList.php';
}

function read($id){
	$idResult = detailsCommande($id);
	$idResult2 = commandeLignes($id);
	// $idResult3 = commandeClient($codec);
	require_once '/views/commande/commandeViewsDetails.php';
}

function add(){
	require_once '/views/commande/commandeViewsAjout.php';
}

function del($id){

	if(isset($_POST['supp'])){
		$idResult = suppressionProduit($id);
	}else{
		$idResult = detailsProduit($id);
	}

	require_once '/views/produit/produitViewsSuppression.php';
}

function edit($id){
	$idResult = detailsCommande($id);
	require_once '/views/commande/commandeViewsEdition.php';

}
