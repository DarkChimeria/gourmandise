<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once '/models/vendeur/vendeurModels.php';

function liste(){
	$idResult = listeVendeur();
	require_once '/views/vendeur/vendeurViewsList.php';
}

function read($id){
	$idResult = detailsVendeur($id);
	$idResult2 = commandeVendeur($id);
	require_once '/views/vendeur/vendeurViewsDetails.php';
}

function add(){
	require_once '/views/vendeur/vendeurViewsAjout.php';
}

function del($id){
	if(isset($_POST['supp'])){
		$idResult = suppressionVendeur($id);
	}else{
		$idResult = detailsVendeur($id);
	}
	require_once '/views/vendeur/vendeurViewsSuppression.php';
}

function edit($id){
	$idResult = detailsVendeur($id);
	require_once '/views/vendeur/vendeurViewsEdition.php';

}
