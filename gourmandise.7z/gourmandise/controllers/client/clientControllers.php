<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once '/models/client/clientModels.php';

function liste(){
	$idResult = listeClients();
	require_once '/views/client/clientViewsList.php';
}

function read($id){
	$idResult = detailsClient($id);
	$idResult2 = commandeClient($id);
	require_once '/views/client/clientViewsDetails.php';
}

function add(){
	require_once '/views/client/clientViewsAjout.php';
}

function del($id){
	if(isset($_POST['supp'])){
		$idResult = suppressionClient($id);
	}else{
		$idResult = detailsClient($id);
	}
	require_once '/views/client/clientViewsSuppression.php';
}

function edit($id){
	$idResult = detailsClient($id);
	require_once '/views/client/clientViewsEdition.php';

}
