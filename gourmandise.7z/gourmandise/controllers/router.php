<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

$add = 'add';
$read = 'read';
$delete = 'delete';
$update = 'edit';
$list = 'list';

switch($gestion){
	case  'produit':
	require_once 'produit/' . $gestion . 'Controllers.php';
	break;
	case  'vendeur':
	require_once 'vendeur/' . $gestion . 'Controllers.php';
	break;
	case  'client':
	require_once 'client/' . $gestion . 'Controllers.php';
	break;
	case  'commande':
	require_once 'commande/' . $gestion . 'Controllers.php';
	break;
	case  'home':
	require_once 'home/' . $gestion . 'Controllers.php';
	break;
	default:
	echo 'Impossible !';
}

if(isset($_GET['action'])){
	$val = $_GET['action'];
}else{
	$val = '';
}



if($val == $delete){
	$id = $_GET['id'];
	del($id);
}elseif($val == $add){
	add();
}elseif($val== $read){
	$id = $_GET['id'];
	read($id);
}elseif($val == $update){
	$id = $_GET['id'];
	edit($id);
}elseif($val == $list){
	liste();
}elseif(empty($val)){
	home();
}

?>