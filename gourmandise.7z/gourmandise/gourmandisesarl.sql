-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 02 Février 2017 à 15:51
-- Version du serveur :  5.7.11
-- Version de PHP :  5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gourmandisesarl`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `code_c` int(11) NOT NULL COMMENT 'Identifiant Client',
  `nom` varchar(35) NOT NULL COMMENT 'Nom du client',
  `adresse` varchar(50) DEFAULT NULL COMMENT AS `Adresse du client`,
  `cp` varchar(5) NOT NULL COMMENT 'Code Postal du client',
  `ville` varchar(25) NOT NULL COMMENT 'Ville du client',
  `telephone` varchar(16) DEFAULT NULL COMMENT AS `Numéro de téléphone du client`
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`code_c`, `nom`, `adresse`, `cp`, `ville`, `telephone`) VALUES
(17, 'TARINAUX Lucien', '12 rue de la Justice', '51100', 'REIMS', '03.26.25.48.87'),
(46, 'MARTUSE', '103 avenue Lear', '51100', 'REIMS', '03.26.03.25.26'),
(47, 'RABIN Sandrine', '21 rue de la MÃ©diterranÃ©e', '51100', 'REIMS', '03.26.14.15.25'),
(48, 'SILLARD Laurence', '15 rue Pasentiers', '51100', 'REIMS', '03.26.11.11.25'),
(49, 'COTOY Sylvie', '12 rue des Ã©cus', '51100', 'REIMS', '03.26.10.25.75'),
(50, 'HELLOU Bernard', '21 rue de la MÃ©diterranÃ©e', '51100', 'REIMS', '03.26.12.25.42'),
(51, 'HENTION Martine', '50 allÃ©e des bons enfants', '51100', 'REIMS', '03.26.12.25.86'),
(52, 'SIBAT Evelyne', '14 rue de la Baltique', '51100', 'REIMS', '03.26.12.23.33'),
(53, 'MARIN Dominique', '24 rue de la Baltique', '51100', 'REIMS', '03.26.10.10.23'),
(54, 'DURDUX Monique', '15 allÃ©e des BÃ©arnais', '51150', 'VITRY LE FRANCOIS', '03.26.42.42.33'),
(55, 'CANILLE Walter', '14 rue Lanterneau', '51100', 'REIMS', '03.26.12.12.87'),
(56, 'BOUQUET Antoinette', '1, rue de la MÃ©diterranÃ©e', '51140', 'ROMAIN', '03.26.78.89.54'),
(57, 'GAUTON Nadine', '5 place des Oiseaux', '51200', 'FISMES', '03.26.53.56.55'),
(58, 'LEGROS Christian', '18 place des Oiseaux', '51200', 'FISMES', '03.26.44.55.66'),
(59, 'DUMOITIERS Lucille', '12 place Centrale', '02320', 'LONGUEVAL', '03.26.86.43.25'),
(60, 'BOUCHE Carole', '4, rue BrulÃ©', '51200', 'FISMES', '03.26.33.96.85');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `numero` int(11) NOT NULL COMMENT 'Numéro de commande',
  `code_v` int(11) NOT NULL COMMENT 'Code Vendeur',
  `code_c` int(11) NOT NULL COMMENT 'Code Commande',
  `date_livraison` datetime DEFAULT NULL COMMENT AS `Date de livraison`,
  `date_commande` datetime DEFAULT NULL COMMENT AS `Date de commande`,
  `total_ht` double DEFAULT '0'COMMENT
) ;

--
-- Contenu de la table `commande`
--

INSERT INTO `commande` (`numero`, `code_v`, `code_c`, `date_livraison`, `date_commande`, `total_ht`, `total_tva`, `etat`) VALUES
(2, 1, 17, '2017-02-01 00:00:00', '2017-02-02 00:00:00', 0, 0, 0),
(3, 1, 17, NULL, NULL, 0, 0, 0),
(4, 1, 17, NULL, NULL, 0, 0, 0),
(6, 1, 17, NULL, NULL, NULL, NULL, NULL),
(7, 1, 17, NULL, NULL, NULL, NULL, NULL),
(8, 1, 17, '2017-02-02 00:00:00', '2017-02-02 00:00:00', 12, 12, 0),
(9, 1, 17, '2017-02-02 00:00:00', '2017-02-02 00:00:00', 12, 12, 0);

-- --------------------------------------------------------

--
-- Structure de la table `ligne_commande`
--

CREATE TABLE `ligne_commande` (
  `numero` int(11) NOT NULL COMMENT 'Numero de commande',
  `numero_ligne` smallint(6) NOT NULL COMMENT 'Numéro de ligne commande',
  `reference` int(11) NOT NULL COMMENT 'Référence du produit',
  `quantite_demandee` smallint(6) DEFAULT '0'COMMENT
) ;

--
-- Contenu de la table `ligne_commande`
--

INSERT INTO `ligne_commande` (`numero`, `numero_ligne`, `reference`, `quantite_demandee`) VALUES
(2, 1, 1004, 6),
(2, 2, 1007, 10);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `reference` int(11) NOT NULL COMMENT 'Réfèrence Produit',
  `designation` varchar(30) NOT NULL COMMENT 'Désignation du produit',
  `quantite` int(11) DEFAULT '0'COMMENT
) ;

--
-- Contenu de la table `produit`
--

INSERT INTO `produit` (`reference`, `designation`, `quantite`, `descriptif`, `prix_unitaire_HT`, `stock`, `poids_piece`) VALUES
(1004, 'FEU DE JOIE LIQUEUR ASSORT.', 500, 'G', 23, 50, 0),
(1007, 'TENDRE FRUIT', 500, 'G', 18, 120, 0),
(1015, 'CARACAO', 500, 'G', 24.5, 50, 0),
(1016, 'COKTAIL', 500, 'G', 33, 40, 0),
(1017, 'ORFIN', 500, 'G', 32, 40, 0),
(3002, 'CARRE PECTO', 500, 'G', 29, 40, 0),
(3004, 'ZAN ALESAN', 25, 'P', 15, 50, 20),
(3010, 'PATES GRISES', 500, 'G', 35, 100, 0),
(3016, 'CARAMEL AU LAIT', 500, 'G', 20, 100, 0),
(3017, 'VIOLETTE TRADITION', 500, 'G', 25, 100, 0),
(4002, 'SUCETTE BOULE FRUIT', 25, 'P', 14, 100, 40),
(4004, 'SUCETTE BOULE POP', 25, 'P', 21, 50, 40),
(4010, 'CARAMBAR', 40, 'P', 18, 20, 15),
(4011, 'CARANOUGA', 40, 'P', 18, 100, 15),
(4012, 'CARAMBAR FRUIT', 40, 'P', 18, 100, 15),
(4013, 'CARAMBAR COLA', 40, 'P', 18, 50, 15),
(4015, 'SOURIS REGLISSE', 500, 'G', 24, 50, 0),
(4016, 'SOURIS CHOCO', 500, 'G', 24, 50, 0),
(4019, 'SCHTROUMPFS VERTS', 500, 'G', 24, 50, 0),
(4020, 'CROCODILE', 500, 'G', 21, 50, 0),
(4022, 'PERSICA', 500, 'G', 28, 20, 0),
(4025, 'COLA CITRIQUE', 500, 'G', 21, 50, 0),
(4026, 'COLA LISSE', 500, 'G', 25, 50, 0),
(4027, 'BANANE', 1000, 'G', 23, 20, 0),
(4029, 'OEUF SUR LE PLAT', 500, 'G', 25, 20, 0),
(4030, 'FRAISIBUS', 500, 'G', 25, 50, 0),
(4031, 'FRAISE TSOIN-TSOIN', 500, 'G', 25, 40, 0),
(4032, 'METRE REGLISSE ROULE', 500, 'G', 19, 50, 0),
(4033, 'MAXI COCOBAT', 1000, 'G', 19, 20, 0),
(4034, 'DENTS VAMPIRE', 500, 'G', 22, 50, 0),
(4036, 'LANGUE COLA CITRIQUE', 500, 'G', 21, 40, 0),
(4037, 'OURSON CANDI', 1000, 'G', 21, 50, 0),
(4039, 'SERPENT ACIDULE', 500, 'G', 21, 20, 0),
(4042, 'TETINE CANDI', 500, 'G', 20, 40, 0),
(4045, 'COLLIER PECCOS', 15, 'P', 21, 50, 50),
(4052, 'TWIST ASSORTIS', 500, 'G', 22, 50, 0),
(4053, 'OURSON GUIMAUVE', 500, 'G', 35, 10, 0),
(4054, 'BOULE COCO MULER', 500, 'G', 34, 10, 0),
(4055, 'COCOMALLOW', 500, 'G', 33, 10, 0),
(4057, 'CRIC-CRAC', 500, 'G', 33, 10, 0),
(4058, 'Test', 0, 'G', 0, 0, 0),
(4062, 'Nouveau Produit', 0, 'G', 0, 0, 0),
(4063, 'Nouveau Produit', 500, 'G', 10, 10, NULL),
(4064, 'Nouveau Produit', 500, 'G', 10, 10, NULL),
(4065, 'Nouveau Produit', 500, 'G', 10, 10, 0),
(4066, 'Nouveau Produit', 500, 'P', 10, 10, 10),
(4067, 'Nouveau Produit', 500, 'P', 110, 100, 10),
(4068, 'Nouveau Produit', 500, 'G', 10, 10, 0),
(4069, 'Nouveau Produit', 500, 'P', 10, 10, 1100),
(4070, 'Test7', 500, 'P', 10, 10, 1),
(4071, 'Bonbon', 0, 'G', 0, 0, 0),
(4072, 'Test13', 0, 'P', 1000, 0, NULL),
(4074, 'dfsdf', 0, '', 0, 0, 0),
(4075, 'gfd', 0, '', 0, 0, 0),
(4076, 'gfdgdfg', 0, '', 0, 0, 0),
(4077, 'fdsdf', 0, '', 0, 0, 0),
(4078, 'gdffg', 0, '', 0, 0, 0),
(4079, 'fghfghjghj', 0, '', 0, 0, 0),
(4080, 'fghh', 0, '', 0, 0, 0),
(4081, 'dsfsf', 0, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `produitacommander`
--
CREATE TABLE `produitacommander` (
`reference` int(11)
,`designation` varchar(30)
,`Quantité à commander` int(7)
);

-- --------------------------------------------------------

--
-- Structure de la table `vendeur`
--

CREATE TABLE `vendeur` (
  `code_v` int(11) NOT NULL COMMENT 'Identifiant Vendeur',
  `nom` varchar(35) NOT NULL COMMENT 'Nom du vendeur',
  `adresse` varchar(50) DEFAULT NULL COMMENT AS `Adresse du vendeur`,
  `cp` varchar(5) NOT NULL COMMENT 'Code Postal du vendeur',
  `ville` varchar(25) NOT NULL COMMENT 'Ville du vendeur',
  `telephone` varchar(16) DEFAULT NULL COMMENT AS `Numéro de téléphone du vendeur`
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `vendeur`
--

INSERT INTO `vendeur` (`code_v`, `nom`, `adresse`, `cp`, `ville`, `telephone`) VALUES
(1, 'FILLARD Sylvain', '77 rue du l\'Adriatique', '51100', 'REIMS', '03.26.12.25.25');

-- --------------------------------------------------------

--
-- Structure de la vue `produitacommander`
--
DROP TABLE IF EXISTS `produitacommander`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `produitacommander`  AS  select `produit`.`reference` AS `reference`,`produit`.`designation` AS `designation`,(120 - `produit`.`stock`) AS `Quantité à commander` from `produit` where (`produit`.`stock` < 50) order by (120 - `produit`.`stock`) ;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`code_c`);

--
-- Index pour la table `vendeur`
--
ALTER TABLE `vendeur`
  ADD PRIMARY KEY (`code_v`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `code_c` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identifiant Client', AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `numero` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Numéro de commande';
--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `reference` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Réfèrence Produit';
--
-- AUTO_INCREMENT pour la table `vendeur`
--
ALTER TABLE `vendeur`
  MODIFY `code_v` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identifiant Vendeur', AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
