<?php
/* Smarty version 3.1.29, created on 2017-02-06 15:51:03
  from "C:\Wamp64\www\gourmandise\templates\vendeur\vendeurViewsDetails.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58989b67ca7ca3_49532369',
  'file_dependency' => 
  array (
    '6138eb4dff7ddddab3f447e087f837bb048f2cc6' => 
    array (
      0 => 'C:\\Wamp64\\www\\gourmandise\\templates\\vendeur\\vendeurViewsDetails.tpl',
      1 => 1486396262,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58989b67ca7ca3_49532369 ($_smarty_tpl) {
?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h2>
					</div>
					<div class="col-md-6">
						<h2>Produits Récents</h2>
					</div>
				</div>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-6">
							<!-- FORMULAIRE -->
							<table class="table table-bordered table-inverse">
								<thead>
									<tr>
										<th colspan="4"><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</th>

									</tr>
								</thead>
								<tbody>
									<tr>      
										<td  rowspan=7><!-- <img class="img-responsive" src="upload_imgs/produits/<?php echo $_smarty_tpl->tpl_vars['image']->value;?>
" alt=""/> --></td>
										<td colspan="2">Code Vendeur</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['codev']->value;?>
</td>
									</tr>
									<tr>
										
										<td colspan="2">Nom du client</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</td>
									</tr>
									<tr>
										<td colspan="2">Adresse</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['adress']->value;?>
</td>
									</tr>
									 
									<tr>
										<td colspan="2">Code Postal</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['cp']->value;?>
</td>
									</tr> 
									<tr>
										<td colspan="2">Ville</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['ville']->value;?>
</td>
									</tr> 
									<tr>
										<td colspan="2">Téléphone</td>
										<td colspan="2"><?php echo $_smarty_tpl->tpl_vars['telephone']->value;?>
</td>
									</tr> 

									<td colspan="5">Informations Complémentaires:</td>

									<tr>
										<td colspan="5">

											<p>

												Latius iam disseminata licentia onerosus bonis omnibus Caesar nullum post haec adhibens modum orientis latera cuncta vexabat nec honoratis parcens nec urbium primatibus nec plebeiis.

												Pandente itaque viam fatorum sorte tristissima, qua praestitutum erat eum vita et imperio spoliari, itineribus interiectis permutatione iumentorum emensis venit Petobionem oppidum Noricorum, ubi reseratae sunt insidiarum latebrae omnes, et Barbatio repente apparuit comes, qui sub eo domesticis praefuit, cum Apodemio agente in rebus milites ducens, quos beneficiis suis oppigneratos elegerat imperator certus nec praemiis nec miseratione ulla posse deflecti.

												Eo adducta re per Isauriam, rege Persarum bellis finitimis inligato repellenteque a conlimitiis suis ferocissimas gentes, quae mente quadam versabili hostiliter eum saepe incessunt et in nos arma moventem aliquotiens iuvant, Nohodares quidam nomine e numero optimatum, incursare Mesopotamiam quotiens copia dederit ordinatus, explorabat nostra sollicite, si repperisset usquam locum vi subita perrupturus.
											</p>


										</td>
									</tr>
								</tbody>
							</table>
							<a href="index.php?gestion=vendeur&action=list" class="btn btn-warning"><i class="fa fa-backward "></i>
								Retourner à la liste des produits
							</a>
						</div>
						<div class="col-md-6">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>
											Numero de commande
										</th>
										<th>
											Total HT
										</th>
										<th>
											Total TVA
										</th>
										<th>
											Date livraison
										</th>
										<th>
											Date commande
										</th>
										<th colspan="3" class="align-center">
											Actions
										</th>
									</tr>
								</thead>
								<tbody>
									<?php
$_from = $_smarty_tpl->tpl_vars['listeCommandes']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_Commandes_0_saved_item = isset($_smarty_tpl->tpl_vars['Commandes']) ? $_smarty_tpl->tpl_vars['Commandes'] : false;
$_smarty_tpl->tpl_vars['Commandes'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['Commandes']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['Commandes']->value) {
$_smarty_tpl->tpl_vars['Commandes']->_loop = true;
$__foreach_Commandes_0_saved_local_item = $_smarty_tpl->tpl_vars['Commandes'];
?>
									<tr>
										<td><?php echo $_smarty_tpl->tpl_vars['Commandes']->value['num'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['Commandes']->value['tht'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['Commandes']->value['ttva'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['Commandes']->value['dliv'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['Commandes']->value['dcom'];?>
</td>
										<td>
												<a href="index.php?gestion=commande&action=read&id=<?php echo $_smarty_tpl->tpl_vars['Commandes']->value['num'];?>
"><i class="fa fa-folder text-infos"></i></a>
												
											</td>
										</tr>
										<?php
$_smarty_tpl->tpl_vars['Commandes'] = $__foreach_Commandes_0_saved_local_item;
}
if ($__foreach_Commandes_0_saved_item) {
$_smarty_tpl->tpl_vars['Commandes'] = $__foreach_Commandes_0_saved_item;
}
?>
									</tbody>
								</table>

						</div>
					</div>
				</div>
				<br>
			</div>
		</div>
	</div>










<?php }
}
