<?php
/* Smarty version 3.1.29, created on 2017-02-06 15:34:47
  from "C:\Wamp64\www\gourmandise\templates\client\clientViewsEdition.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_58989797d018a3_42804057',
  'file_dependency' => 
  array (
    'b3c1ecb4eb283644c48bbf057e6cab1ebe69e483' => 
    array (
      0 => 'C:\\Wamp64\\www\\gourmandise\\templates\\client\\clientViewsEdition.tpl',
      1 => 1486395283,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58989797d018a3_42804057 ($_smarty_tpl) {
?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h2>
					</div>
					<div class="col-md-6">
						<h2>Produits Récents</h2>
					</div>
				</div>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-6">
							<!-- FORMULAIRE -->
							<form role="form" method="POST" onsubmit="return validateForm()" name="Form">
								<div class="form-group">
									<label for="exampleInputPassword1">
										Nom
									</label>
									<input class="form-control" type="text" name="nom" value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
" required> 
									<span id="result"></span>
								</div>
								<div class="form-group">
									<label for="exampleInputPassword1">
										Adresse
									</label>
									<input class="form-control" type="text" name="adresse" value="<?php echo $_smarty_tpl->tpl_vars['adress']->value;?>
" required> 
									<span id="result"></span>
								</div>
								<div class="form-group">
									<label for="exampleInputPassword1">
										Code Postal
									</label>
									<input class="form-control" type="text" name="cp" value="<?php echo $_smarty_tpl->tpl_vars['cp']->value;?>
" required> 
									<span id="result"></span>
								</div>
								<div class="form-group">
									<label for="exampleInputPassword1">
										Ville
									</label>
									<input class="form-control" type="text" name="ville" value="<?php echo $_smarty_tpl->tpl_vars['ville']->value;?>
" required> 
									<span id="result"></span>
								</div>
								<div class="form-group">
									<label for="exampleInputPassword1">
										Téléphone
									</label>
									<input class="form-control" type="text" name="telephone" value="<?php echo $_smarty_tpl->tpl_vars['telephone']->value;?>
" required> 
									<span id="result"></span>
								</div>
								
								<button type="submit" class="btn btn-warning" name="update">Modifier</button>
							</form>
							<br>
							<a href="index.php?gestion=vendeur&action=list" class="btn btn-default"><i class="fa fa-backward "></i>
								Retourner à la liste des produits
							</a>

						</div>
						<div class="col-md-6">

							<?php if ($_smarty_tpl->tpl_vars['success']->value == '1') {?>
							<div class='alert alert-success'>
								<button class='close' data-dismiss='alert'>&times;</button>
								<strong>Super !</strong>  Le client a bien été Modifié
							</div>
							<?php } elseif ($_smarty_tpl->tpl_vars['success']->value == '2') {?>
							<div class='alert alert-warning'>
								<button class='close' data-dismiss='alert'>&times;</button>
								<strong>Attention !</strong>  Vous n'avez rien modifié
							</div>
							<?php } elseif ($_smarty_tpl->tpl_vars['success']->value == '3') {?>
							<div class='alert alert-warning'>
								<button class='close' data-dismiss='alert'>&times;</button>
								<strong>Attention !</strong>  Vous n'avez rien modifié
							</div>
							<?php } else { ?>
							<?php }?>
						</div>
					</div>
				</div>
				<br>
			</div>
		</div>
	</div>










<?php }
}
