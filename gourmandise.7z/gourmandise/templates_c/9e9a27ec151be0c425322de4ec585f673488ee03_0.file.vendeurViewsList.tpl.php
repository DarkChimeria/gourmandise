<?php
/* Smarty version 3.1.29, created on 2017-02-06 14:31:46
  from "C:\Wamp64\www\gourmandise\templates\vendeur\vendeurViewsList.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_589888d2c54098_03022938',
  'file_dependency' => 
  array (
    '9e9a27ec151be0c425322de4ec585f673488ee03' => 
    array (
      0 => 'C:\\Wamp64\\www\\gourmandise\\templates\\vendeur\\vendeurViewsList.tpl',
      1 => 1486391438,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_589888d2c54098_03022938 ($_smarty_tpl) {
?>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-6">

								<?php if ($_smarty_tpl->tpl_vars['success']->value == '1') {?>
								<div class='alert alert-success'>
									<button class='close' data-dismiss='alert'>&times;</button>
									<strong>Super !</strong>  Le Vendeur a bien été ajouté
									<a href="index.php?gestion=Vendeur&action=add">Voulez-vous ajouter un autre Vendeur ?</a>
								</div>
								<?php } elseif ($_smarty_tpl->tpl_vars['success']->value == '2') {?>
								<div class='alert alert-success'>
									<button class='close' data-dismiss='alert'>&times;</button>
									<strong>Super !</strong>  Le Vendeur a bien été Modifié
								</div>
								<?php } elseif ($_smarty_tpl->tpl_vars['success']->value == '3') {?>
								<div class='alert alert-warning'>
									<button class='close' data-dismiss='alert'>&times;</button>
									<strong>Super !</strong>  Le Vendeur a bien été supprimé
								</div>
								<?php } else { ?>
								<?php }?>

								

								<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 | <?php echo $_smarty_tpl->tpl_vars['nblignes']->value;?>
 Vendeur(s) | <?php echo $_smarty_tpl->tpl_vars['nbpages']->value;?>
 pages</h2>

								<table class="table table-hover">
									<thead>
										<tr>
											<th>
												Code_V
											</th>
											<th>
												Nom Prénom
											</th>
											<th>
												Ville
											</th>
											<th colspan="3" class="align-center">
												Actions
											</th>
										</tr>
									</thead>
									<tbody>
										<?php
$_from = $_smarty_tpl->tpl_vars['pagination']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_Vendeur_0_saved_item = isset($_smarty_tpl->tpl_vars['Vendeur']) ? $_smarty_tpl->tpl_vars['Vendeur'] : false;
$_smarty_tpl->tpl_vars['Vendeur'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['Vendeur']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['Vendeur']->value) {
$_smarty_tpl->tpl_vars['Vendeur']->_loop = true;
$__foreach_Vendeur_0_saved_local_item = $_smarty_tpl->tpl_vars['Vendeur'];
?>
										<tr>
											<td><?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['code_v'];?>
</td>
											<td><?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['name'];?>
</td>
											<td><?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['ville'];?>
</td>
											<td>
												<a href="index.php?gestion=vendeur&action=read&id=<?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['code_v'];?>
"><i class="fa fa-folder text-infos"></i></a>
												<a href="index.php?gestion=vendeur&action=edit&id=<?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['code_v'];?>
"><i class="fa fa-pencil text-warning"></i></a>
												<a href="index.php?gestion=vendeur&action=delete&id=<?php echo $_smarty_tpl->tpl_vars['Vendeur']->value['code_v'];?>
"><i class="fa fa-close text-danger"></i></a>
											</td>
										</tr>
										<?php
$_smarty_tpl->tpl_vars['Vendeur'] = $__foreach_Vendeur_0_saved_local_item;
}
if ($__foreach_Vendeur_0_saved_item) {
$_smarty_tpl->tpl_vars['Vendeur'] = $__foreach_Vendeur_0_saved_item;
}
?>
									</tbody>
								</table>
								
								
								<?php
$_from = $_smarty_tpl->tpl_vars['numero']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_num_1_saved_item = isset($_smarty_tpl->tpl_vars['num']) ? $_smarty_tpl->tpl_vars['num'] : false;
$_smarty_tpl->tpl_vars['num'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['num']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['num']->value) {
$_smarty_tpl->tpl_vars['num']->_loop = true;
$__foreach_num_1_saved_local_item = $_smarty_tpl->tpl_vars['num'];
?>
								<tr>
									<a class="btn btn-info" role="button"h href="index.php?gestion=vendeur&action=list&page=<?php echo $_smarty_tpl->tpl_vars['num']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num']->value;?>
</a>
								</tr>
								<?php
$_smarty_tpl->tpl_vars['num'] = $__foreach_num_1_saved_local_item;
}
if ($__foreach_num_1_saved_item) {
$_smarty_tpl->tpl_vars['num'] = $__foreach_num_1_saved_item;
}
?>
								<br><br>
								Nombre de Vendeurs par page : <?php echo $_smarty_tpl->tpl_vars['nbAafficher']->value;?>


								<a href="index.php?num=10">10</a>

								<form method="POST">
									<select>
										<option value="5">5</option>
										<option value="10">10</option>
										<option value="15">15</option>
										<option value="20">20</option>
									</select>
									<button type="submit" class="btn btn-success" name="nbAafficher">Afficher</button>
								</form>
							</div>
						</div>
					</div>









<?php }
}
