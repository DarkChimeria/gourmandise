<?php
/* Smarty version 3.1.29, created on 2017-02-06 10:45:07
  from "C:\Wamp64\www\gourmandise\templates\home\homeViewsList.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_589853b3bab319_91415640',
  'file_dependency' => 
  array (
    '2b694998c485d357a142a818ff41f647963590bd' => 
    array (
      0 => 'C:\\Wamp64\\www\\gourmandise\\templates\\home\\homeViewsList.tpl',
      1 => 1486377906,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_589853b3bab319_91415640 ($_smarty_tpl) {
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
		</div>
		<div class="col-md-8">

			<h2><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 | <?php echo $_smarty_tpl->tpl_vars['nblignes']->value;?>
 entrée(s) | <?php echo $_smarty_tpl->tpl_vars['nbpages']->value;?>
 pages</h2>

			<table class="table table-hover">
				<thead>
					<tr>
						<th>
							Vendeur
						</th>
						<th>
							CA en €
						</th>
											<!-- <th colspan="3" class="align-center">
												Actions
											</th> -->
										</tr>
									</thead>
									<tbody>
										<?php
$_from = $_smarty_tpl->tpl_vars['pagination']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_Home_0_saved_item = isset($_smarty_tpl->tpl_vars['Home']) ? $_smarty_tpl->tpl_vars['Home'] : false;
$_smarty_tpl->tpl_vars['Home'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['Home']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['Home']->value) {
$_smarty_tpl->tpl_vars['Home']->_loop = true;
$__foreach_Home_0_saved_local_item = $_smarty_tpl->tpl_vars['Home'];
?>
										<tr>
											<td><?php echo $_smarty_tpl->tpl_vars['Home']->value['name'];?>
</td>
											<td><?php echo $_smarty_tpl->tpl_vars['Home']->value['ca'];?>
</td>
											
											<!-- <td>
												<a href="index.php?gestion=Home&action=read&id=<?php echo $_smarty_tpl->tpl_vars['Home']->value['code_v'];?>
"><i class="fa fa-folder text-infos"></i></a>
												<a href="index.php?gestion=Home&action=edit&id=<?php echo $_smarty_tpl->tpl_vars['Home']->value['code_v'];?>
"><i class="fa fa-pencil text-warning"></i></a>
												<a href="index.php?gestion=Home&action=delete&id=<?php echo $_smarty_tpl->tpl_vars['Home']->value['code_v'];?>
"><i class="fa fa-close text-danger"></i></a>
											</td> -->
										</tr>
										<?php
$_smarty_tpl->tpl_vars['Home'] = $__foreach_Home_0_saved_local_item;
}
if ($__foreach_Home_0_saved_item) {
$_smarty_tpl->tpl_vars['Home'] = $__foreach_Home_0_saved_item;
}
?>
									</tbody>
								</table>
								
								
								<?php
$_from = $_smarty_tpl->tpl_vars['numero']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_num_1_saved_item = isset($_smarty_tpl->tpl_vars['num']) ? $_smarty_tpl->tpl_vars['num'] : false;
$_smarty_tpl->tpl_vars['num'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['num']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['num']->value) {
$_smarty_tpl->tpl_vars['num']->_loop = true;
$__foreach_num_1_saved_local_item = $_smarty_tpl->tpl_vars['num'];
?>
								<tr>
									<a class="btn btn-info" role="button"h href="index.php?page=<?php echo $_smarty_tpl->tpl_vars['num']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['num']->value;?>
</a>
								</tr>
								<?php
$_smarty_tpl->tpl_vars['num'] = $__foreach_num_1_saved_local_item;
}
if ($__foreach_num_1_saved_item) {
$_smarty_tpl->tpl_vars['num'] = $__foreach_num_1_saved_item;
}
?>
								<br><br>
								Nombre de vendeurs par page : <?php echo $_smarty_tpl->tpl_vars['nbAafficher']->value;?>


								<a href="index.php?num=10">10</a>

								<form method="POST">
									<select>
										<option value="5">5</option>
										<option value="10">10</option>
										<option value="15">15</option>
										<option value="20">20</option>
									</select>
									<button type="submit" class="btn btn-success" name="nbAafficher">Afficher</button>
								</form>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
							</div>
							<div class="col-md-8">
								<h2><?php echo $_smarty_tpl->tpl_vars['title2']->value;?>
 | <?php echo $_smarty_tpl->tpl_vars['nblignes']->value;?>
 entrée(s) | <?php echo $_smarty_tpl->tpl_vars['nbpages']->value;?>
 pages</h2>

								<table class="table table-hover">
									<thead>
										<tr>
											<th>
												Code_C
											</th>
											<th>
												Nom du client
											</th>
											<th>
												CA en €
											</th>
										</tr>
									</thead>
									<tbody>
										<?php
$_from = $_smarty_tpl->tpl_vars['caClient']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_Home1_2_saved_item = isset($_smarty_tpl->tpl_vars['Home1']) ? $_smarty_tpl->tpl_vars['Home1'] : false;
$_smarty_tpl->tpl_vars['Home1'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['Home1']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['Home1']->value) {
$_smarty_tpl->tpl_vars['Home1']->_loop = true;
$__foreach_Home1_2_saved_local_item = $_smarty_tpl->tpl_vars['Home1'];
?>
										<tr>
											<td><?php echo $_smarty_tpl->tpl_vars['Home1']->value['code_c'];?>
</td>
											<td><?php echo $_smarty_tpl->tpl_vars['Home1']->value['name'];?>
</td>
											<td><?php echo $_smarty_tpl->tpl_vars['Home1']->value['CAC'];?>
</td>											
										</tr>
										<?php
$_smarty_tpl->tpl_vars['Home1'] = $__foreach_Home1_2_saved_local_item;
}
if ($__foreach_Home1_2_saved_item) {
$_smarty_tpl->tpl_vars['Home1'] = $__foreach_Home1_2_saved_item;
}
?>
									</tbody>
								</table>
							</div>
						</div>
					</div><?php }
}
