<?php
/* Smarty version 3.1.29, created on 2017-02-02 13:19:14
  from "C:\Wamp64\www\gourmandise\templates\header.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_589331d2a67208_29784566',
  'file_dependency' => 
  array (
    '582c787af49f8734f6d87dc04736e84e5e898983' => 
    array (
      0 => 'C:\\Wamp64\\www\\gourmandise\\templates\\header.tpl',
      1 => 1486041553,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_589331d2a67208_29784566 ($_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>

	<meta name="description" content="Source code generated using layoutit.com">
	<meta name="author" content="LayoutIt!">

	<link href="templates/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="templates/bootstrap/css/style.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
</head>
<body>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<br><br><br><br><br><?php }
}
