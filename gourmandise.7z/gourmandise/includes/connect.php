<?php
// Définir les informations de connexion
define('SERVER','localhost');
define('BASEDEDONNEES','gourmandisesarl');
define('UTILISATEUR','root');
define('MOTDEPASSE','');