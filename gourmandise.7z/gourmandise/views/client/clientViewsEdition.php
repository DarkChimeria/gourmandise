<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();



if(!isset($_POST['update'])){
	$listeProduits = array();
	$i = 0;

	$row=$idResult->fetch(PDO::FETCH_ASSOC);
	$codec = $row['code_c'];
	$name = $row['nom'];
	$adress= $row['adresse'];
	$cp = $row['cp'];
	$ville = $row['ville'];
	$telephone = $row['telephone'];



	$template->assign('title','Détails d\'un produit');

	$template->assign('codec', $codec);
	$template->assign('name', $name);
	$template->assign('adress', $adress);
	$template->assign('cp', $cp);
	$template->assign('ville', $ville);
	$template->assign('telephone', $telephone);





}elseif(isset($_POST['update'])){

	$row=$idResult->fetch(PDO::FETCH_ASSOC);
	$codec = $row['code_c'];
	$name = $row['nom'];
	$adress= $row['adresse'];
	$cp = $row['cp'];
	$ville = $row['ville'];
	$telephone = $row['telephone'];
	
	if($name == $_POST['nom'] && $adress == $_POST['adresse'] && $cp == $_POST['cp'] && $ville == $_POST['ville'] && $telephone == $_POST['telephone']){

		Header( 'Location: index.php?gestion=client&action=edit&id=' . $codec . '&success=2' );

	}else{


		$name = $_POST['nom'];
		$adress= $_POST['adresse'];
		$cp = $_POST['cp'];
		$ville = $_POST['ville'];
		$telephone = $_POST['telephone'];

		$idResult = editionClient($name,$adress,$cp,$ville,$telephone,$id);
	}
}




if(!empty($_GET['success'])){
	$template->assign('success', $_GET['success']);
}else{
	$template->assign('success', '0');
}




$template->display('templates/header.tpl');
$template->display('templates/client/clientViewsEdition.tpl');
$template->display('templates/footer.tpl');