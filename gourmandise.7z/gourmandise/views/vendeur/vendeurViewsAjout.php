<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();

if(!isset($_POST['designation']) && !isset($_POST['descriptif'])){
	$designation = '';
	$descriptif = '';
}elseif (empty($_POST['designation'])){
	Header( 'Location: index.php?gestion=produit&action=add&success=1' );
	$template->assign('success', $_GET['success']);
}else{

	$imgFile = $_FILES['produit_image']['name'];
	$tmp_dir = $_FILES['produit_image']['tmp_name'];
	$imgSize = $_FILES['produit_image']['size'];


	if(empty($imgFile)){

		$errMSG = '<div class="box-body"><div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><h4><i class="icon fa fa-check"></i> Attention !</h4>Aucune image sélectionnée</div></div>';
	}
	else
	{
   $upload_dir = 'upload_imgs/produits/'; // upload directory

   $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension

   // valid image extensions
   $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

   // rename uploading image
   $image = rand(1000,1000000).".".$imgExt;

   // allow valid image file formats
   if(in_array($imgExt, $valid_extensions)){   
    // Check file size '5MB'
   	if($imgSize < 5000000)    {
   		move_uploaded_file($tmp_dir,$upload_dir.$image);
   	}
   	else{
   		$errMSG = '<div class="box-body"><div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><h4><i class="icon fa fa-check"></i> Attention !</h4>L\'image sélectionnée est trop volumineuse</div></div>';
   	}
   }
   else{
   	$errMSG = '<div class="box-body"><div class="alert alert-warning alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><h4><i class="icon fa fa-check"></i> Attention !</h4>Seuls les images de type : JPEG, JPG, PNG, GIF sont acceptées</div></div>';  
   }
}

if(!isset($errMSG))
{

	$designation = $_POST['designation'];
	$quantite = $_POST['quantite'];
	$descriptif = $_POST['descriptif'];
	$prixunitaire = $_POST['prixunitaire'];
	$stock = $_POST['stock'];

	if($_POST['piece'] == ""){
		$piece= '0';
	}else{
		$piece=$_POST['piece'];
	}
	$imgFile = $_FILES['produit_image']['name'];
	$idResult = ajoutProduit($designation,$quantite,$descriptif,$prixunitaire,$stock,$piece,$image);

    // Header( 'Location: ../index.php?success=1' );
	$msgalert = '<div class="box-body"><div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><h4><i class="icon fa fa-check"></i> Super!</h4>Les paramètres ont été édités avec succès !</div></div>';
}
}

if(!empty($_GET['success'])){
	$template->assign('success', $_GET['success']);
}else{
	$template->assign('success', '0');
}


if ( isset($msgalert)){
     // treat the succes case ex:
	echo $msgalert;
}elseif( isset($errMSG)){

	echo $errMSG;
}


$template->display('templates/header.tpl');
$template->display('templates/produit/produitViewsAjout.tpl');
$template->display('templates/footer.tpl');