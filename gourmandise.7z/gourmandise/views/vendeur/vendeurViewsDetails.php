<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();

// $listeProduits = array();
// $i = 0;

$row=$idResult->fetch(PDO::FETCH_ASSOC);
// $row2=$idResult2->fetch(PDO::FETCH_ASSOC);
$codev = $row['code_v'];
$name = $row['nom'];
$adress= $row['adresse'];
$cp = $row['cp'];
$ville = $row['ville'];
$telephone = $row['telephone'];
// $qtdemandee = $row2['quantite_demandee'];


$template->assign('title','Détails d\'un vendeur');

$template->assign('codev', $codev);
$template->assign('name', $name);
$template->assign('adress', $adress);
$template->assign('cp', $cp);
$template->assign('ville', $ville);
$template->assign('telephone', $telephone);

$listeCommandes = array();
$i = 0;


while($row2=$idResult2->fetch(PDO::FETCH_ASSOC)){
	$listeCommandes[$i]['codec'] = $row2['code_v'];
	$listeCommandes[$i]['num'] = $row2['numero'];
	$listeCommandes[$i]['tht'] = $row2['total_ht'];
	$listeCommandes[$i]['ttva'] = $row2['total_tva'];
	$listeCommandes[$i]['dliv'] = $row2['date_livraison'];
	$listeCommandes[$i]['dcom'] = $row2['date_commande'];
	$i++;
}

$nblignes = $idResult2->rowCount();
$template->assign('title2','Liste des commandes');
$template->assign('nblignes',$nblignes);
$template->assign('listeCommandes', $listeCommandes);


$template->display('templates/header.tpl');
$template->display('templates/vendeur/vendeurViewsDetails.tpl');
$template->display('templates/footer.tpl');