<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();

$caClient = array();
$i = 0;

while($row1=$idResult1->fetch(PDO::FETCH_ASSOC)){
	$caClient[$i]['CAC'] = $row1['CAC'];
	$caClient[$i]['name'] = $row1['nom'];
	$caClient[$i]['code_c'] = $row1['code_c'];
	// $caClient[$i]['descriptif'] = $row['descriptif'];
	// $caClient[$i]['prix_unitaire_HT'] = $row['prix_unitaire_HT'];
	$i++;
}
$template->assign('caClient', $caClient);
$nblignes = $idResult->rowCount();
$template->assign('title','CA par vendeur');
$template->assign('title2','Meilleur CA des 5 meilleurs');
$template->assign('nblignes',$nblignes);
// $template->assign('listeProduits', $listeProduits);


if(!empty($_GET['success'])){
	$template->assign('success', $_GET['success']);
}else{
	$template->assign('success', '0');
}

if(isset($_POST['nbAafficher']) == 10){

$nbproduits = 10;

	$template->assign('nbAafficher', 'test');
}else{

	$nbproduits = 5;
	$template->assign('nbAafficher', 'testsansrien');
}



$nbpages = ceil($nblignes / $nbproduits);
$template->assign('nbpages', $nbpages);

if (isset($_GET['page']))
{
    $page = $_GET['page']; // On récupère le numéro de la page indiqué dans l'adresse (livredor.php?page=4)
}
else // La variable n'existe pas, c'est la première fois qu'on charge la page
{
    $page = 1; // On se met sur la page 1 (par défaut)
}
 
// On calcule le numéro du premier message qu'on prend pour le LIMIT de MySQL
$premierMessageAafficher = ($page - 1) * $nbproduits;


$idResul = caParVendeur($premierMessageAafficher,$nbproduits);
$pagination = array();
$a = 0;
while($row=$idResult->fetch(PDO::FETCH_ASSOC)){
	$pagination[$a]['code_v'] = $row['code_v'];
	$pagination[$a]['ca'] = $row['CA'];
	$pagination[$a]['name'] = $row['nom'];

	$a++;
}

$numero = array();

for ($b = 1 ; $b <= $nbpages ; $b++)
{
	$numero[] = $b;
}
$template->assign('numero', $numero);

$template->assign('pagination', $pagination);


$template->display('templates/header.tpl');
$template->display('templates/home/homeViewsList.tpl');
$template->display('templates/footer.tpl');