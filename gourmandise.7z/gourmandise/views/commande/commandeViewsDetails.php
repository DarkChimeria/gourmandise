<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();


$row=$idResult->fetch(PDO::FETCH_ASSOC);

$num = $row['numero'];
$codev = $row['code_v'];
$codec = $row['code_c'];
$dl = $row['date_livraison'];
$dc = $row['date_commande'];
$tht = $row['total_ht'];
$ttva = $row['total_tva'];
$etat = $row['etat'];


$template->assign('title','Détails d\'une commande');

$template->assign('num', $num);
$template->assign('codev', $codev);
$template->assign('codec', $codec);
$template->assign('dl', $dl);
$template->assign('dc', $dc);
$template->assign('tht', $tht);
$template->assign('ttva', $ttva);
$template->assign('etat', $etat);


$listeLignes = array();
$i = 0;


while($row2=$idResult2->fetch(PDO::FETCH_ASSOC)){
	$listeLignes[$i]['ref'] = $row2['reference'];
	$listeLignes[$i]['nl'] = $row2['numero_ligne'];
	$listeLignes[$i]['num'] = $row2['numero'];
	$listeLignes[$i]['qtdemandee'] = $row2['quantite_demandee'];
	$i++;
}
$nblignes = $idResult2->rowCount();
$template->assign('title2','Liste des Produits');
$template->assign('nblignes',$nblignes);
$template->assign('listLignes', $listeLignes);



// $row3=$idResult3->fetch(PDO::FETCH_ASSOC);
// $codec = $row3['codec'];

$template->display('templates/header.tpl');
$template->display('templates/commande/commandeViewsDetails.tpl');
$template->display('templates/footer.tpl');