<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();

// $listeProduits = array();
// $i = 0;

// $row=$idResult->fetch(PDO::FETCH_ASSOC);
// $ref = $row['reference'];
// $design = $row['designation'];
// $pu = $row['prix_unitaire_HT'];


// $template->assign('title','Détails d\'un produit');

// $template->assign('ref', $ref);
// $template->assign('design', $design);
// $template->assign('pu', $pu);

if(!isset($_POST['code_v']) && !isset($_POST['code_c'])){
	$codev = '';
	$codec = '';
}else{
	$codev = $_POST['code_v'];
	$codec = $_POST['code_c'];
	$dateliv = $_POST['date_livraison'];
	$datecommande = $_POST['date_commande'];
	$totalht = $_POST['total_ht'];
	$totaltva = $_POST['total_tva'];
	$etat= $_POST['etat'];
	$idResult = ajoutCommande($codev,$codec,$dateliv,$datecommande,$totalht,$totaltva,$etat);
}

if(!empty($_GET['success'])){
	$template->assign('success', $_GET['success']);
}else{
	$template->assign('success', '0');
}

$template->display('templates/header.tpl');
$template->display('templates/commande/commandeViewsAjout.tpl');
$template->display('templates/footer.tpl');
