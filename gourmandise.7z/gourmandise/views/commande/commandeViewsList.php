<?php
/**************************************************************************
Script de cours PHP - MVC - Smarty
**************************************************************************/

require_once 'includes/libs/Smarty.class.php';


$template = new Smarty();

$listeCommandes = array();
$i = 0;

while($row=$idResult->fetch(PDO::FETCH_ASSOC)){
	$listeCommandes[$i]['numero'] = $row['numero'];
	$listeCommandes[$i]['code_v'] = $row['code_v'];
	$listeCommandes[$i]['code_c'] = $row['code_c'];
	$listeCommandes[$i]['date_livraison'] = $row['date_livraison'];
	$listeCommandes[$i]['date_commande'] = $row['date_commande'];
	$listeCommandes[$i]['total_ht'] = $row['total_ht'];
	$listeCommandes[$i]['total_tva'] = $row['total_tva'];
	$listeCommandes[$i]['etat'] = $row['etat'];
	$i++;
}
$nblignes = $idResult->rowCount();
$template->assign('title','Liste des commandes');
$template->assign('nblignes',$nblignes);
$template->assign('listCommandes', $listeCommandes);


if(!empty($_GET['success'])){
	$template->assign('success', $_GET['success']);
}else{
	$template->assign('success', '0');
}




$template->display('templates/header.tpl');
$template->display('templates/commande/commandeViewsList.tpl');
$template->display('templates/footer.tpl');