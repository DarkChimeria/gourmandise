$fichier = 'image.jpg';
<?php
$fichier = 'upload_imgs/produits/imageproduit.jpg';
$dimensions = @getimagesize($fichier);

